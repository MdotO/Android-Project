package com.example.hp.dailyselfie;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.hardware.Camera;
import android.hardware.camera2.CameraAccessException;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.EventLog;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

/**
 * Created by HP on 7/19/2017.
 */

public class Selfie_Activity extends AppCompatActivity implements SurfaceHolder.Callback {
private android.hardware.Camera camera=null;boolean running=false ;private SurfaceView surfaceView;
private SurfaceHolder surfaceHolder;
    private Random random;
    private android.hardware.Camera openFrontFacingCameraGingerbread() {
        int cameraCount = 0;
        android.hardware.Camera cam = null;
        android.hardware.Camera.CameraInfo cameraInfo = new android.hardware.Camera.CameraInfo();
        cameraCount = android.hardware.Camera.getNumberOfCameras();
        for (int camIdx = 0; camIdx < cameraCount; camIdx++) {
            android.hardware.Camera.getCameraInfo(camIdx, cameraInfo);
            if (cameraInfo.facing == android.hardware.Camera.CameraInfo.CAMERA_FACING_FRONT) {
                try {
                    cam = android.hardware.Camera.open(camIdx);
                } catch (RuntimeException e) {
                    Log.e("THOUUUUUU", "Camera failed to open: " + e.getLocalizedMessage());
                }
            }
        }

        return cam;
    }
    private boolean checkCameraHardware(Context context) {
        if (context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)){
            // this device has a camera
            Log.i("this","has camera");
            return true;
        } else {
            // no camera on this device
            Log.i("this","n9t have camera");
            return false;
        }
    }
    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        random=new Random();
        setContentView(R.layout.selfie_layout);
        surfaceView = (SurfaceView) findViewById(R.id.surfaceView);
        surfaceHolder = surfaceView.getHolder();
        surfaceHolder.addCallback(this);

        ((SurfaceView) findViewById(R.id.surfaceView)).setOnTouchListener(new SurfaceView.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getActionIndex() == MotionEvent.ACTION_DOWN) {
                    camera.takePicture(new android.hardware.Camera.ShutterCallback() {
                        @Override
                        public void onShutter() {
                        }
                    }, null, new android.hardware.Camera.PictureCallback() {
                        @Override
                        public void onPictureTaken(byte[] data, android.hardware.Camera camera) {
                            try {
                                Thread.sleep(2000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                            try {
                                camera.startPreview();
                                running = true;
                            } catch (Exception e) {
                                Log.e("this", "is not working rn");}

                            String root = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString();
                            File myDir = new File(root + "/DailySelfie_images");
                            myDir.mkdirs();
                            Random generator = new Random();
                            int n = 10000;
                            n = generator.nextInt(n);
                            String fname = "Image-" + n + ".jpg";
                            File file = new File(myDir, fname);
                            if (file.exists())
                                file.delete();
                            try {
                                FileOutputStream out = new FileOutputStream(file);
                                BitmapFactory.decodeByteArray(data,0,data.length).compress(Bitmap.CompressFormat.JPEG, 90, out);
                                out.flush();
                                out.close();
                            }
                            catch (Exception e) {
                                e.printStackTrace();
                            }


                            // Tell the media scanner about the new file so that it is
                            // immediately available to the user.
                            MediaScannerConnection.scanFile(getBaseContext(), new String[] { file.toString() }, null,
                                    new MediaScannerConnection.OnScanCompletedListener() {
                                        public void onScanCompleted(String path, Uri uri) {
                                            Log.i("ExternalStorage", "Scanned " + path + ":");
                                            Log.i("ExternalStorage", "-> uri=" + uri);
                                        }
                                    });




                        }
                    });
                }
                return false;
            }
        });
    }
    @Override
    protected void onResume(){
        super.onResume();
        surfaceHolder =((SurfaceView)findViewById(R.id.surfaceView)).getHolder();
        surfaceHolder.addCallback(this);
        checkCameraHardware(getApplicationContext());
        try{
            camera=Camera.open();

        }
        catch (Exception sd){
            Log.i("this","no cmaera");}
    }
@Override
public void surfaceCreated(SurfaceHolder h){
    try {
        camera.setPreviewDisplay(h);
        camera.startPreview();
    } catch (IOException e) {
        e.printStackTrace();
    }
                    running=true;
}
@Override
    public void surfaceChanged(SurfaceHolder h,int format,int width,int height){

if(h.getSurface()==null)
    return ;
    if(!running)
    camera.stopPreview();
    running =false;
    try {


    camera.setPreviewDisplay(h);   }
    catch (IOException e){e.printStackTrace();}
    camera.startPreview();
    running=true;



}
@Override
    public void surfaceDestroyed(SurfaceHolder h){


}

@Override
    protected void onPause() {


    super.onPause();
    if (camera != null) {
        if (running) {
            try {
                camera.stopPreview();
                running = false;
            } catch (Exception e) {
                Log.e("this", "doesnt work");
            }
        }
     camera.release();camera=null;
    }

}
}
