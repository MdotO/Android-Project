package com.example.hp.dailyselfie;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by HP on 7/28/2017.
 */
public class AlarmReceiver extends BroadcastReceiver{

    @Override
    public void onReceive(Context context, Intent intent){
        Log.i("ON","RECEIVED!!!!");

        Intent mNotificationIntent = new Intent (context, Selfie_Activity.class);
        PendingIntent mContentIntent = PendingIntent.getActivity (context, 0, mNotificationIntent, 0);
        Notification.Builder notificationBuilder = new Notification.Builder (context).setTicker ("Daily Selfie").setSmallIcon (android.R.drawable.ic_menu_camera).setAutoCancel (true).setContentTitle ("Daily Selfie").setContentText ("It,s time for a daily selfie!!!").setContentIntent (mContentIntent);
        NotificationManager mNotificationManager = (NotificationManager) context.getSystemService (Context.NOTIFICATION_SERVICE);
        mNotificationManager.notify (1, notificationBuilder.build ());


    }
}