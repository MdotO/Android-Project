package com.example.hp.dailyselfie;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {
    public SharedPreferences sharedPreferences;
    public boolean status;int num;
    private AlarmManager alarmManager;
    private Intent intent;EditText editText;
    private PendingIntent pendingIntent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sharedPreferences=getPreferences(MODE_PRIVATE);status=sharedPreferences.getBoolean("status",false);
        alarmManager=(AlarmManager)getSystemService(ALARM_SERVICE);intent=new Intent();intent.setAction("ABCDE");
        pendingIntent=PendingIntent.getBroadcast(getApplicationContext(),0,intent,0);
        Log.i("This","Works fine till now");
        editText=(EditText)findViewById(R.id.editText);
        final ToggleButton toggleButton=(ToggleButton)findViewById(R.id.toggleButton);
        editText.setText("4");
        toggleButton.setChecked(status);
        Button button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getApplicationContext(),Selfie_Activity.class));
            }
        });

        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {boolean set=true;
                    if (Integer.parseInt(editText.getText().toString()) >10 )
                    {set=false;editText.setText("4");
                        toggleButton.setChecked(false);
                    Toast.makeText(getBaseContext(),"Not more than 10 per day", Toast.LENGTH_SHORT).show();}
                    else if  (Integer.parseInt(editText.getText().toString())<1)
                    {
                        toggleButton.setChecked(false); set=false;editText.setText("4"); Toast.makeText(getBaseContext(),"Atleast 1 Notification per day",Toast.LENGTH_SHORT).show();}
                    if (set)
                    { alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime(), AlarmManager.INTERVAL_DAY*(long)1.0/(Integer.parseInt(editText.getText().toString())), pendingIntent);
                        Toast.makeText(getBaseContext(), "Daily Selfie notifications status: "+editText.getText().toString()+ " Notification(s) per day starting from your current time", Toast.LENGTH_SHORT).show();

                        status = true;}



                } else {

                    status = false;
                    alarmManager.cancel(pendingIntent);
                    Toast.makeText(getBaseContext(), "Daily Selfie notifications status: Not Set", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }
    @Override
    protected void onPause(){

        SharedPreferences.Editor m=sharedPreferences.edit();
        m.putBoolean("status",status);
        m.commit();
        super.onPause();
    }




}
